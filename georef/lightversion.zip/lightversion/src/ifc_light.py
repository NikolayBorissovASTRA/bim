#!/usr/bin/env python3
"""
IFC4X3_ADD2 Lightweight Pyramid Generator
Minimal implementation using templates and modular functions
"""

import math
from pathlib import Path
from typing import Any, Dict, Tuple, Optional
import ifcopenshell
import ifcopenshell.guid
import yaml


class IFCLight:
    """Lightweight IFC4X3_ADD2 pyramid generator with Swiss LV95 georeferencing."""

    def __init__(self, template_dir: str = "../templates"):
        """Initialize with templates from directory."""
        self.templates = self._load_templates(template_dir)
        self.ifc = None
        self.context = None
        self.site = None
        self.owner = None
        self._pyramid_counter = 0

    def _load_templates(self, template_dir: str) -> dict:
        """Load configuration templates from multiple YAML files."""
        templates = {}
        template_files = {
            'coordinates': 'coordinates.yaml',
            'geometry': 'geometry.yaml',
            'ifc_structure': 'ifc_structure.yaml',
            'naming': 'naming.yaml',
            'property_sets': 'property_sets.yaml',
            'test_data': 'test_data.yaml'
        }

        for key, filename in template_files.items():
            filepath = Path(template_dir) / filename
            if filepath.exists():
                with open(filepath, 'r') as f:
                    data = yaml.safe_load(f)
                    # Merge the data into templates
                    if data:
                        templates.update(data)

        return templates

    def create_file(self, project_name: Optional[str] = None) -> ifcopenshell.file:
        """Create minimal IFC file with required hierarchy."""
        self.ifc = ifcopenshell.file(schema="IFC4X3_ADD2")

        # Create minimal required entities using templates
        self._setup_header()
        self._setup_project(project_name)
        self._setup_units()
        self._setup_context()
        self._setup_site()

        return self.ifc

    def _setup_header(self):
        """Set minimal file header."""
        self.ifc.header.file_name.name = "pyramid_light.ifc"
        self.ifc.header.file_description.description = ("IFC4X3_ADD2",)

    def _setup_project(self, name: Optional[str] = None):
        """Create project with owner history."""
        # Owner history (simplified)
        self.owner = self.ifc.create_entity(
            "IfcOwnerHistory",
            OwningUser=self.ifc.create_entity("IfcPersonAndOrganization",
                ThePerson=self.ifc.create_entity("IfcPerson", FamilyName="LightGenerator"),
                TheOrganization=self.ifc.create_entity("IfcOrganization", Name="IFCLight")
            ),
            OwningApplication=self.ifc.create_entity("IfcApplication",
                ApplicationDeveloper=self.ifc.create_entity("IfcOrganization", Name="IFCLight"),
                Version="1.0",
                ApplicationFullName="IFC Light Generator",
                ApplicationIdentifier="IFC_LIGHT"
            )
        )

        # Project
        project_template = self.templates['ifc_templates']['project']
        self.project = self.ifc.create_entity(
            "IfcProject",
            GlobalId=ifcopenshell.guid.new(),
            Name=name or project_template['name'],
            OwnerHistory=self.owner
        )

    def _setup_units(self):
        """Create unit assignment from template."""
        units = []
        for unit_spec in self.templates['ifc_templates']['units']:
            unit = self.ifc.create_entity(
                "IfcSIUnit",
                UnitType=unit_spec['type'],
                Prefix=unit_spec['prefix'],
                Name=unit_spec['name']
            )
            units.append(unit)

        self.ifc.create_entity(
            "IfcUnitAssignment",
            Units=units
        )

    def _setup_context(self):
        """Create geometric representation context."""
        ctx = self.templates['ifc_templates']['context']
        ref_point = self.templates['reference_point']

        # CRS for Swiss LV95
        crs = self.ifc.create_entity(
            "IfcProjectedCRS",
            Name=f"EPSG:{ref_point['epsg_code']}"
        )

        # Map conversion
        map_conversion = self.ifc.create_entity(
            "IfcMapConversion",
            SourceCRS=crs,
            TargetCRS=self.ifc.create_entity(
                "IfcGeometricRepresentationContext",
                ContextIdentifier=ctx['identifier'],
                ContextType=ctx['type'],
                CoordinateSpaceDimension=ctx['dimension'],
                Precision=ctx['precision'],
                WorldCoordinateSystem=self.ifc.create_entity(
                    "IfcAxis2Placement3D",
                    Location=self.ifc.create_entity("IfcCartesianPoint", Coordinates=(0., 0., 0.))
                )
            ),
            Eastings=ref_point['easting'],
            Northings=ref_point['northing'],
            OrthogonalHeight=ref_point['height'],
            XAxisAbscissa=math.cos(math.radians(ref_point['rotation_deg'])),
            XAxisOrdinate=math.sin(math.radians(ref_point['rotation_deg'])),
            Scale=1.0
        )

        # Store context reference
        self.context = map_conversion.TargetCRS

    def _setup_site(self):
        """Create site with placement."""
        self.site = self.ifc.create_entity(
            "IfcSite",
            GlobalId=ifcopenshell.guid.new(),
            Name="Site",
            OwnerHistory=self.owner,
            ObjectPlacement=self.ifc.create_entity(
                "IfcLocalPlacement",
                RelativePlacement=self.ifc.create_entity(
                    "IfcAxis2Placement3D",
                    Location=self.ifc.create_entity("IfcCartesianPoint", Coordinates=(0., 0., 0.))
                )
            )
        )

        # Aggregate to project
        self.ifc.create_entity(
            "IfcRelAggregates",
            GlobalId=ifcopenshell.guid.new(),
            OwnerHistory=self.owner,
            RelatingObject=self.project,
            RelatedObjects=[self.site]
        )

    def add_pyramid(
        self,
        lv95_coords: Tuple[float, float, float],
        name: Optional[str] = None,
        element_type: str = "REF",
        sector: str = "S01",
        phase: str = "PL",
        pyramid_data: Optional[Dict[str, Any]] = None
    ) -> Any:
        """Add pyramid at LV95 coordinates using templates."""
        self._pyramid_counter += 1

        # Transform LV95 to local coordinates
        local_coords = self._transform_coordinates(lv95_coords)

        # Generate name if not provided
        if not name:
            name = self._generate_name(element_type, sector, phase)

        # Create pyramid geometry from template
        representation = self._create_pyramid_geometry(local_coords)

        # Create building element
        pyramid = self.ifc.create_entity(
            "IfcBuildingElementProxy",
            GlobalId=ifcopenshell.guid.new(),
            Name=name,
            OwnerHistory=self.owner,
            ObjectPlacement=self.ifc.create_entity(
                "IfcLocalPlacement",
                PlacementRelTo=self.site.ObjectPlacement,
                RelativePlacement=self.ifc.create_entity(
                    "IfcAxis2Placement3D",
                    Location=self.ifc.create_entity(
                        "IfcCartesianPoint",
                        Coordinates=local_coords
                    )
                )
            ),
            Representation=representation
        )

        # Add to spatial structure
        self._add_to_site(pyramid)

        # Add ASTRA properties
        self._add_properties(pyramid, lv95_coords, pyramid_data)

        return pyramid

    def _transform_coordinates(self, lv95: Tuple[float, float, float]) -> Tuple[float, float, float]:
        """Transform LV95 to local coordinates using LoGeoRef50."""
        ref = self.templates['reference_point']

        # Translate to reference point
        de = lv95[0] - ref['easting']
        dn = lv95[1] - ref['northing']

        # Rotate (inverse transformation)
        angle_rad = math.radians(ref['rotation_deg'])
        cos_a = math.cos(-angle_rad)
        sin_a = math.sin(-angle_rad)

        x = de * cos_a - dn * sin_a
        y = de * sin_a + dn * cos_a
        z = lv95[2] - ref['height']

        return (x, y, z)

    def _create_pyramid_geometry(self, offset: Tuple[float, float, float]) -> Any:
        """Create pyramid mesh from template."""
        pyramid_spec = self.templates['pyramid']

        # Create vertices from template
        vertices = []
        for v in pyramid_spec['vertices_template']:
            vertices.append(self.ifc.create_entity(
                "IfcCartesianPoint",
                Coordinates=v
            ))

        # Create faces from template - directly as index lists
        faces = pyramid_spec['faces_template']

        # Create tessellated face set
        face_set = self.ifc.create_entity(
            "IfcTriangulatedFaceSet",
            Coordinates=self.ifc.create_entity(
                "IfcCartesianPointList3D",
                CoordList=[v.Coordinates for v in vertices]
            ),
            CoordIndex=faces,
            Closed=True
        )

        # Create shape representation
        shape = self.ifc.create_entity(
            "IfcShapeRepresentation",
            ContextOfItems=self.context,
            RepresentationIdentifier="Body",
            RepresentationType="Tessellation",
            Items=[face_set]
        )

        return self.ifc.create_entity(
            "IfcProductDefinitionShape",
            Representations=[shape]
        )

    def _generate_name(self, element_type: str, sector: str, phase: str) -> str:
        """Generate name using convention pattern."""
        pattern = self.templates['naming']['patterns']['convention']
        return pattern.format(
            project="A1",
            type=element_type,
            sector=sector,
            number=self._pyramid_counter,
            phase=phase
        )

    def _add_to_site(self, element: Any):
        """Add element to site's spatial structure."""
        # Check for existing containment
        for rel in self.ifc.by_type("IfcRelContainedInSpatialStructure"):
            if rel.RelatingStructure == self.site:
                # Add to existing relationship
                rel.RelatedElements = list(rel.RelatedElements) + [element]
                return

        # Create new containment
        self.ifc.create_entity(
            "IfcRelContainedInSpatialStructure",
            GlobalId=ifcopenshell.guid.new(),
            OwnerHistory=self.owner,
            RelatingStructure=self.site,
            RelatedElements=[element]
        )

    def _add_properties(self, element: Any, lv95_coords: Tuple[float, float, float],
                       pyramid_data: Optional[Dict[str, Any]] = None):
        """Add ASTRA property sets from template."""

        # Add ASTRA_Georeferencing property set
        props_spec = self.templates['property_sets']['ASTRA_Georeferencing']

        # Create properties
        properties = []
        values = {
            'BP_E': lv95_coords[0],
            'BP_N': lv95_coords[1],
            'BP_H': lv95_coords[2],
            'Rotation': math.radians(self.templates['reference_point']['rotation_deg']),
            'EPSG_Code': str(self.templates['reference_point']['epsg_code'])
        }

        for prop_spec in props_spec['properties']:
            prop = self.ifc.create_entity(
                "IfcPropertySingleValue",
                Name=prop_spec['name'],
                NominalValue=self.ifc.create_entity(
                    prop_spec['type'],
                    values[prop_spec['name']]
                )
            )
            properties.append(prop)

        # Create georeferencing property set
        pset_geo = self.ifc.create_entity(
            "IfcPropertySet",
            GlobalId=ifcopenshell.guid.new(),
            Name="ASTRA_Georeferencing",
            OwnerHistory=self.owner,
            HasProperties=properties
        )

        # Relate to element
        self.ifc.create_entity(
            "IfcRelDefinesByProperties",
            GlobalId=ifcopenshell.guid.new(),
            OwnerHistory=self.owner,
            RelatingPropertyDefinition=pset_geo,
            RelatedObjects=[element]
        )

        # Add ASTRA_PyramidData property set if pyramid_data is provided
        if pyramid_data:
            pyramid_props = []

            # Define property types for pyramid data
            prop_types = {
                'measurement_date': 'IfcLabel',
                'accuracy_class': 'IfcLabel',
                'measurement_method': 'IfcLabel',
                'operator': 'IfcLabel',
                'status': 'IfcLabel',
                'remarks': 'IfcText'
            }

            for key, value in pyramid_data.items():
                if key in prop_types and value is not None:
                    prop = self.ifc.create_entity(
                        "IfcPropertySingleValue",
                        Name=key,
                        NominalValue=self.ifc.create_entity(
                            prop_types[key],
                            str(value)
                        )
                    )
                    pyramid_props.append(prop)

            if pyramid_props:
                # Create pyramid data property set
                pset_pyramid = self.ifc.create_entity(
                    "IfcPropertySet",
                    GlobalId=ifcopenshell.guid.new(),
                    Name="ASTRA_CommonPSet_LoGeoRef",
                    OwnerHistory=self.owner,
                    HasProperties=pyramid_props
                )

                # Relate to element
                self.ifc.create_entity(
                    "IfcRelDefinesByProperties",
                    GlobalId=ifcopenshell.guid.new(),
                    OwnerHistory=self.owner,
                    RelatingPropertyDefinition=pset_pyramid,
                    RelatedObjects=[element]
                )

    def save(self, filepath: str):
        """Save IFC file."""
        self.ifc.write(filepath)

    def add_pyramids_from_template(self):
        """Add test pyramids from template configuration."""
        for pyramid_spec in self.templates['test_pyramids']:
            self.add_pyramid(
                lv95_coords=tuple(pyramid_spec['lv95']),
                name=pyramid_spec['name'],
                element_type=pyramid_spec['type'],
                sector=pyramid_spec['sector'],
                phase=pyramid_spec.get('phase', 'PL')
            )


def main():
    """Simple usage example."""
    # Create generator with templates directory
    generator = IFCLight("../templates")

    # Create IFC file
    generator.create_file("Highway A1 - Light Version")

    # Add pyramids from template
    generator.add_pyramids_from_template()

    # Add custom pyramid
    generator.add_pyramid(
        lv95_coords=(2679525.0, 1151708.0, 501.0),
        element_type="MON",
        sector="BR01",
        phase="CO"
    )

    # Save file
    output_file = "../output/pyramid_light.ifc"
    generator.save(output_file)
    print(f"✅ Created {output_file}")

    # Report summary
    pyramids = generator.ifc.by_type("IfcBuildingElementProxy")
    print(f"📊 Generated {len(pyramids)} pyramids")
    for p in pyramids:
        print(f"   - {p.Name}")


if __name__ == "__main__":
    main()